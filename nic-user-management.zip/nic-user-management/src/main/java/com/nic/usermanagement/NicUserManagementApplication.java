package com.nic.usermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NicUserManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(NicUserManagementApplication.class, args);
    }
}