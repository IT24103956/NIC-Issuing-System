package com.nic.usermanagement.config;

import com.nic.usermanagement.model.User;
import com.nic.usermanagement.model.Role;
import com.nic.usermanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create or update super admin
        try {
            User superAdmin = new User(
                    "Super Admin",
                    "superadmin@nic.lk",
                    passwordEncoder.encode("admin123"),
                    "0112345678",
                    "NIC Headquarters",
                    Role.ROLE_SUPERADMIN
            );
            superAdmin.setId(1L); // Set the ID to ensure update instead of insert
            userService.saveUser(superAdmin);
            System.out.println("✅ Super Admin created/updated: superadmin@nic.lk / admin123");
        } catch (Exception e) {
            System.out.println("ℹ️ Super Admin: " + e.getMessage());
        }

        // Create or update admin
        try {
            User admin = new User(
                    "Admin User",
                    "admin@nic.lk",
                    passwordEncoder.encode("admin123"),
                    "0112345679",
                    "NIC Branch Office",
                    Role.ROLE_ADMIN
            );
            admin.setId(2L); // Set the ID to ensure update instead of insert
            userService.saveUser(admin);
            System.out.println("✅ Admin User created/updated: admin@nic.lk / admin123");
        } catch (Exception e) {
            System.out.println("ℹ️ Admin User: " + e.getMessage());
        }

        System.out.println("\n========================================");
        System.out.println("✅ NIC User Management System Started!");
        System.out.println("📍 Home: http://localhost:8080");
        System.out.println("📍 Login: http://localhost:8080/login");
        System.out.println("📍 Register: http://localhost:8080/register");
        System.out.println("📍 Super Admin: superadmin@nic.lk / admin123");
        System.out.println("📍 Admin: admin@nic.lk / admin123");
        System.out.println("========================================\n");
    }
}