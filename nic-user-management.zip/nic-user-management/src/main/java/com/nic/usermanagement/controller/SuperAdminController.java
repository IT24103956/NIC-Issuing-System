package com.nic.usermanagement.controller;

import com.nic.usermanagement.model.Application;
import com.nic.usermanagement.model.User;
import com.nic.usermanagement.service.ApplicationService;
import com.nic.usermanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/superadmin")
public class SuperAdminController {

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private UserService userService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Application> pendingApps = applicationService.getUnassignedApplications();
        List<User> admins = userService.getAdmins();
        model.addAttribute("pendingApps", pendingApps);
        model.addAttribute("admins", admins);
        return "superadmin-dashboard";
    }

    @PostMapping("/applications/assign")
    public String assignApplication(@RequestParam Long appId, @RequestParam Long adminId) {
        applicationService.assignApplication(appId, adminId);
        return "redirect:/superadmin/dashboard";
    }

    @PostMapping("/admins/create")
    public String createAdmin(@RequestParam String fullName, @RequestParam String email, @RequestParam String password) {
        userService.createAdmin(fullName, email, password);
        return "redirect:/superadmin/dashboard";
    }

    @GetMapping("/admins/delete/{id}")
    public String deleteAdmin(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/superadmin/dashboard";
    }
}