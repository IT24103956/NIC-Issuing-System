package com.nic.usermanagement.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Authentication authentication, Model model) {
        if (authentication != null && authentication.isAuthenticated()) {
            model.addAttribute("loggedIn", true);
            model.addAttribute("user", authentication.getPrincipal());

            // Check if user should be redirected to admin dashboard
            boolean isSuperAdmin = authentication.getAuthorities()
                    .stream().anyMatch(a -> a.getAuthority().equals("ROLE_SUPERADMIN"));

            boolean isAdmin = authentication.getAuthorities()
                    .stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

            if (isSuperAdmin) {
                return "redirect:/superadmin/dashboard";
            } else if (isAdmin) {
                return "redirect:/admin/dashboard";
            }
        } else {
            model.addAttribute("loggedIn", false);
        }
        return "home";
    }

    @GetMapping("/home")
    public String homePage(Authentication authentication, Model model) {
        return home(authentication, model);
    }

    @GetMapping("/feedback")
    public String showFeedbackPage(Authentication authentication, Model model) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }
        model.addAttribute("user", authentication.getPrincipal());
        return "feedback";
    }
}