package com.nic.usermanagement.repository;

import com.nic.usermanagement.model.Application;
import com.nic.usermanagement.model.User;
import com.nic.usermanagement.model.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByAssignedAdmin(User user);
    List<Application> findByAssignedAdminIsNull();
    List<Application> findByStatus(ApplicationStatus status);
}