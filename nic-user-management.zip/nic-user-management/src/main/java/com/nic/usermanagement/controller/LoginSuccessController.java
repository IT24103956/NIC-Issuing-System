package com.nic.usermanagement.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginSuccessController {

    @GetMapping("/login-success")
    public String handleLoginSuccess(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            // Check user roles and redirect accordingly
            boolean isSuperAdmin = authentication.getAuthorities()
                    .contains(new SimpleGrantedAuthority("ROLE_SUPERADMIN"));

            boolean isAdmin = authentication.getAuthorities()
                    .contains(new SimpleGrantedAuthority("ROLE_ADMIN"));

            if (isSuperAdmin) {
                return "redirect:/superadmin/dashboard";
            } else if (isAdmin) {
                return "redirect:/admin/dashboard";
            }
        }
        // Default redirect for regular users
        return "redirect:/";
    }
}