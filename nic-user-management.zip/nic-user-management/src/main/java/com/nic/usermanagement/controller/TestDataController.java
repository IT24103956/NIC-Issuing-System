package com.nic.usermanagement.controller;

import com.nic.usermanagement.model.Application;
import com.nic.usermanagement.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test")
public class TestDataController {

    @Autowired
    private ApplicationService applicationService;

    @GetMapping("/create-applications")
    public String createSampleApplications() {
        try {
            // Create sample applications
            Application app1 = new Application(
                    "John Doe", "123456789V", "0771234567",
                    "123 Main Street, Colombo", "New NIC", "First time application"
            );
            applicationService.createApplication(app1);

            Application app2 = new Application(
                    "Jane Smith", "987654321V", "0777654321",
                    "456 Galle Road, Galle", "NIC Renewal", "Renewal application"
            );
            applicationService.createApplication(app2);

            Application app3 = new Application(
                    "Robert Brown", "456789123V", "0771112222",
                    "789 Kandy Road, Kandy", "NIC Replacement", "Lost my NIC card"
            );
            applicationService.createApplication(app3);

            return "redirect:/superadmin/dashboard?success=Sample applications created";
        } catch (Exception e) {
            return "redirect:/superadmin/dashboard?error=" + e.getMessage();
        }
    }
}