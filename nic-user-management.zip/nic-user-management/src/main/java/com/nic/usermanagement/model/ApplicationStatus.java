package com.nic.usermanagement.model;

public enum ApplicationStatus {
    PENDING,
    UNDER_REVIEW,
    APPROVED,
    REJECTED,
    COMPLETED
}