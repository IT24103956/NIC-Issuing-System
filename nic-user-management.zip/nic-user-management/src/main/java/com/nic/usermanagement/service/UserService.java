package com.nic.usermanagement.service;

import com.nic.usermanagement.model.User;
import com.nic.usermanagement.model.Role;
import com.nic.usermanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElse(null);
    }

    public User saveUser(User user) throws Exception {
        if (user.getId() == null) {
            // New user
            if (userRepository.existsByEmail(user.getEmail())) {
                throw new Exception("Email already exists: " + user.getEmail());
            }
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            // Existing user
            User existingUser = userRepository.findById(user.getId()).orElse(null);
            if (existingUser != null) {
                if (!existingUser.getEmail().equals(user.getEmail())) {
                    if (userRepository.existsByEmail(user.getEmail())) {
                        throw new Exception("Email already exists: " + user.getEmail());
                    }
                }
                if (user.getPassword() == null || user.getPassword().isEmpty()) {
                    user.setPassword(existingUser.getPassword());
                } else {
                    user.setPassword(passwordEncoder.encode(user.getPassword()));
                }
            }
        }
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public User registerUser(User user) throws Exception {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new Exception("Email already exists: " + user.getEmail());
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.ROLE_USER);
        return userRepository.save(user);
    }

    public List<User> getAdmins() {
        return userRepository.findByRole(Role.ROLE_ADMIN);
    }

    public List<User> getSuperAdmins() {
        return userRepository.findByRole(Role.ROLE_SUPERADMIN);
    }

    public void createAdmin(String fullName, String email, String password) {
        User admin = new User(fullName, email, passwordEncoder.encode(password), "", "", Role.ROLE_ADMIN);
        userRepository.save(admin);
    }
}