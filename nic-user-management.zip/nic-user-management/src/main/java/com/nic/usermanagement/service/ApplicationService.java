package com.nic.usermanagement.service;

import com.nic.usermanagement.model.Application;
import com.nic.usermanagement.model.User;
import com.nic.usermanagement.model.ActionLog;
import com.nic.usermanagement.model.ApplicationStatus;
import com.nic.usermanagement.repository.ApplicationRepository;
import com.nic.usermanagement.repository.ActionLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ActionLogRepository actionLogRepository;

    @Autowired
    private UserService userService;

    public List<Application> getUnassignedApplications() {
        return applicationRepository.findByAssignedAdminIsNull();
    }

    public List<Application> getAssignedApplications(User admin) {
        return applicationRepository.findByAssignedAdmin(admin);
    }

    public Application getApplicationById(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found with ID: " + id));
    }

    @Transactional
    public void assignApplication(Long appId, Long adminId) {
        Application app = getApplicationById(appId);
        User admin = userService.getUserById(adminId);

        if (app.getAssignedAdmin() != null) {
            throw new IllegalStateException("Application is already assigned");
        }
        app.setAssignedAdmin(admin);
        applicationRepository.save(app);
        // FIX: Use getFullName() instead of getFullName()
        logAction("Assigned application " + appId + " to admin " + admin.getFullName(), admin, app.getId());
    }

    public void updateStatus(Long appId, ApplicationStatus status, User user) {
        Application app = getApplicationById(appId);
        app.setStatus(status);
        applicationRepository.save(app);
        logAction("Updated status to " + status + " for application " + appId, user, app.getId());
    }

    public void deleteApplication(Long appId, User user) {
        Application app = getApplicationById(appId);
        logAction("Deleted application " + appId, user, app.getId());
        applicationRepository.delete(app);
    }

    public Application createApplication(Application application) {
        return applicationRepository.save(application);
    }

    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    private void logAction(String action, User user, Long applicationId) {
        ActionLog log = new ActionLog();
        log.setAction(action);
        log.setUser(user);
        log.setTimestamp(LocalDateTime.now());
        log.setApplicationId(applicationId);
        actionLogRepository.save(log);
    }
}