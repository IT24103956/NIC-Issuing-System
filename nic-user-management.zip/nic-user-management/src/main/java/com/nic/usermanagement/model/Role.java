package com.nic.usermanagement.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SUPERADMIN
}