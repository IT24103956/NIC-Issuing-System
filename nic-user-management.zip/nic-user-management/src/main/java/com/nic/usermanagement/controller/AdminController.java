package com.nic.usermanagement.controller;

import com.nic.usermanagement.model.Application;
import com.nic.usermanagement.model.User;
import com.nic.usermanagement.model.ApplicationStatus;
import com.nic.usermanagement.service.ApplicationService;
import com.nic.usermanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private UserService userService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        User user = (User) authentication.getPrincipal();
        List<Application> apps = applicationService.getAssignedApplications(user);
        model.addAttribute("apps", apps);
        return "admin-dashboard";
    }

    @GetMapping("/applications")
    public String applications(Model model) {
        List<Application> apps = applicationService.getAllApplications();
        model.addAttribute("apps", apps);
        return "admin-applications";
    }

    @PostMapping("/applications/{id}/status")
    public String updateStatus(@PathVariable Long id, @RequestParam ApplicationStatus status, Authentication authentication) {
        User user = (User) authentication.getPrincipal();
        applicationService.updateStatus(id, status, user);
        return "redirect:/admin/applications";
    }

    @GetMapping("/applications/{id}/delete")
    public String deleteApplication(@PathVariable Long id, Authentication authentication) {
        User user = (User) authentication.getPrincipal();
        applicationService.deleteApplication(id, user);
        return "redirect:/admin/applications";
    }
}